import "./Profile.css";
function Profile(){
    return(
        <div className = "layout">
            <img src="assets/355990.jpg" alt="Profile" />
            <h1 className = "Name">Navin Dansaikul</h1>
            <hr></hr>
        </div>
    )
}
export default Profile;